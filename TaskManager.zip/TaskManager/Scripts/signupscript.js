var check = function() {
  if (document.getElementById('password').value ==
    document.getElementById('checkpassword').value) {
    document.getElementById('message').style.color = 'green';
    document.getElementById('message').innerHTML = 'matching';
  } else {
    document.getElementById('message').style.color = 'red';
    document.getElementById('message').innerHTML = 'not matching';
  }
}


function myFunction() {
  var x = document.getElementById("password");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}

function myFunction2() {
  var y = document.getElementById("checkpassword");
  if (y.type === "password") {
    y.type = "text";
  } else {
    y.type = "password";
  }
}